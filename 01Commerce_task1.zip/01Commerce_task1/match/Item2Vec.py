import pickle
import time
from gensim.models import Word2Vec
from sklearn.externals import joblib

class LoadCorpora(object):
    def __init__(self, s):
        self.UserItem = s

    def __iter__(self):
        for userid,items in self.UserItem.items():
            yield [str(val) for val in items.keys()]

class recommend_w2v():
    def __init__(self, train_data, test_data, item2cate,model_dir):
        self.train_data = train_data
        self.test_data = test_data
        self.item2cate = item2cate
        self.topk = 300
        self.topn = 50
        self.UserItem = dict()
        self.itemid_set = set()
        self.model = None
        self.model_dir = model_dir

    def hdata(self):
        # 用户-物品的矩阵
        for val in self.train_data.values:
            userid = val[0]
            itemid = val[1]
            self.UserItem.setdefault(userid, {})
            self.UserItem[userid].setdefault(itemid, 0)
            self.UserItem[userid][itemid] = 1
            self.itemid_set.add(itemid)

    def train(self):
        self.model = Word2Vec(LoadCorpora(self.UserItem),
                              window=10, sg=1, hs=0,
                              negative=10,  # for negative sampling
                              alpha=0.03, min_alpha=0.0007,
                              seed=14)
        # size=800, min_count=1, workers=32, iter=100)
        #joblib.dump(self.model, self.model_dir)

    def recommend(self,userid):
        rank = dict()
        if userid not in self.UserItem.keys():
            return dict()
        action_items = self.UserItem[userid]
        for itemid, score in action_items.items():
            if itemid not in self.itemid_set:
                continue
            itemidlist = self.model.wv.most_similar(str(itemid), topn = self.topk)
            for val in itemidlist:
                rank.setdefault(val[0], 0)
                rank[val[0]] += val[1] * score
        temp = sorted(rank.items(), key=lambda x: x[1], reverse=True)[0:self.topn]
        if len(temp) < 1:
            return dict()
        return dict(temp)

    def test_score(self):
        inum = 0
        score = 0
        t1 = time.time()
        for val in self.test_data.values:
            inum += 1
            userid = val[0]
            itemid = val[1]
            items = self.recommend(userid)
            if len(items) == 0:
                continue
            if str(itemid) in items.keys():
                score += 1
            if inum % 10 == 0:
                t2 = time.time()
                print('time:%d,num:%d,score:%d ' % (t2-t1, inum, score))
                t1 = t2

    def load_model(self):
        self.model = joblib.load(self.model_dir)
        print('load model ok')

if __name__ == '__main__':
    infile = '../data/matchdata.dat'
    model_dir = '../save/item2vec/item2vec.model'
    match_train_data, match_test_data, item2cate = pickle.load(open(infile, mode='rb'))
    hd = recommend_w2v(match_train_data, match_test_data, item2cate,model_dir)
    t1 = time.time()
    hd.hdata()
    t2 = time.time()
    print('hdata time:%d' % (t2-t1))

    t1 = time.time()
    hd.train()
    t2 = time.time()
    print('train time:%d' % (t2-t1))

    #hd.load_model()
    t1 = time.time()
    hd.test_score()
    t2 = time.time()
    print('test time:%d' % (t2-t1))
