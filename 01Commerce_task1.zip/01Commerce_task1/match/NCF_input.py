import numpy as np
import pandas as pd
import pickle
import tensorflow as tf
import os

DATA_DIR = '../data/matchdata.dat'
DATA_PATH = '../save/'
COLUMN_NAMES = ['userid', 'itemid', 'categoryid', 'behavior', 'timestamp']
MAXNUM = 5000

def re_index(s):
    i = 0
    s_map = {}
    for key in s:
        s_map[key] = i
        i += 1
    return s_map

def load_data():
    match_train_data, match_test_data, _ = pickle.load(open(DATA_DIR, mode='rb'))
    train = pd.DataFrame(match_train_data,columns=COLUMN_NAMES)
    test = pd.DataFrame(match_test_data,columns=COLUMN_NAMES)
    all_data = pd.concat([train,test])
    all_data = all_data.reset_index(drop=True)
    user_set = set(all_data['userid'])
    item_set = set(all_data['itemid'])
    user_size = len(user_set)
    item_size = len(item_set)

    user_bought = {}
    for i in range(len(all_data)):
        u = all_data['userid'][i]
        t = all_data['itemid'][i]
        if u not in user_bought:
            user_bought[u] = []
        user_bought[u].append(t)

    user_negative = {}
    for key in user_bought:
        user_negative[key] = list(item_set - set(user_bought[key]))[0:MAXNUM]

    labels  = np.ones(len(train),dtype=np.int32)

    train_features = train[['userid','itemid']].reset_index(drop=True)
    train_labels = labels.tolist()

    test_features = test[['userid','itemid']].reset_index(drop=True)
    test_labels = test['itemid'].tolist()
    print('load_data ok')

    return ((train_features, train_labels),
            (test_features, test_labels),
            (user_size, item_size),
            (user_bought, user_negative))


def add_negative(features,user_negative,labels,numbers,is_training):
    feature_user,feature_item,labels_add,feature_dict = [],[],[],{}

    for i in range(len(features)):
        user = features['userid'][i]
        item = features['itemid'][i]
        label = labels[i]

        feature_user.append(user)
        feature_item.append(item)
        labels_add.append(label)

        neg_samples = np.random.choice(user_negative[user],size=numbers,replace=False).tolist()

        if is_training:
            for k in neg_samples:
                feature_user.append(user)
                feature_item.append(k)
                labels_add.append(0)

        else:
            for k in neg_samples:
                feature_user.append(user)
                feature_item.append(k)
                labels_add.append(k)


    feature_dict['user'] = feature_user
    feature_dict['item'] = feature_item
    print('add_negative ok',is_training)

    return feature_dict,labels_add



def dump_data(features,labels,user_negative,num_neg,is_training):
    if not os.path.exists(DATA_PATH):
        os.makedirs(DATA_PATH)

    features,labels = add_negative(features,user_negative,labels,num_neg,is_training)

    data_dict = dict([('user', features['user']),
                      ('item', features['item']), ('label', labels)])

    if is_training:
        np.save(os.path.join(DATA_PATH, 'train_data.npy'), data_dict)
    else:
        np.save(os.path.join(DATA_PATH, 'test_data.npy'), data_dict)



def train_input_fn(features,labels,batch_size,user_negative,num_neg):
    data_path = os.path.join(DATA_PATH, 'train_data.npy')
    if not os.path.exists(data_path):
        dump_data(features, labels, user_negative, num_neg, True)

    data = np.load(data_path,allow_pickle=True).item()
    print("Loading training data finished!")

    dataset = tf.data.Dataset.from_tensor_slices(data)
    dataset = dataset.shuffle(100000).batch(batch_size)

    return dataset


def eval_input_fn(features, labels, user_negative, test_neg):
    """ Construct testing dataset. """
    data_path = os.path.join(DATA_PATH, 'test_data.npy')
    if not os.path.exists(data_path):
        dump_data(features, labels, user_negative, test_neg, False)

    data = np.load(data_path,allow_pickle=True).item()
    print("Loading testing data finished!")
    dataset = tf.data.Dataset.from_tensor_slices(data)
    dataset = dataset.batch(test_neg + 1)

    return dataset






