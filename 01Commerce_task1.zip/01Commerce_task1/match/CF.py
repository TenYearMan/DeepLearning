import pandas as pd
import numpy as np
import math
import time
import pickle
import gc


def coCF_u2u(train,save_n=600):
    # 物品-用户的矩阵
    ItemUser = dict()
    UserItem = dict()
    # 用户-用户的共现矩阵（用户i和用户j共同喜欢的物品数）
    C = dict()
    # 用户i喜欢的物品数
    N = dict()

    for val in train.values:
        userid = val[0]
        itemid = val[1]
        ItemUser.setdefault(itemid, {})
        UserItem.setdefault(userid, {})
        ItemUser[itemid][userid] = 1
        UserItem[userid][itemid] = 1

    for _, users in ItemUser.items():
        for userid in users.keys():
            N.setdefault(userid, 0)
            N[userid] += 1
            C.setdefault(userid, {})
            for i in users.keys():
                if userid == i:
                    continue
                C[userid].setdefault(i, 0)
                C[userid][i] += 1

    W = dict()
    for i, ilist in C.items():
        W.setdefault(i, {})
        for j, cij in ilist.items():
            W[i][j] = cij / N[i]

    sorted_item_sim = {k: list(sorted(v.items(),\
                                      key=lambda x: x[1], reverse=True)[0:save_n]) \
                       for k, v in W.items()}

    return sorted_item_sim, ItemUser, UserItem

def coCF_i2i_test(train,save_n=600):
    # 用户-物品的矩阵
    UserItem = dict()
    # 物品-物品的共现矩阵
    C = dict()
    # 喜欢物品i的用户数
    N = dict()
    for val in train.values:
        userid = val[0]
        itemid = val[1]
        UserItem.setdefault(userid, {})
        UserItem[userid].setdefault(itemid, 0)
        UserItem[userid][itemid] += 1

    for _, itemids in UserItem.items():
        for itemid in itemids.keys():
            N.setdefault(itemid, 0)
            N[itemid] += 1
            C.setdefault(itemid, {})
            for i in itemids.keys():
                if itemid == i:
                    continue
                C[itemid].setdefault(i, 0)
                C[itemid][i] += 1

    W = dict()
    for i, ilist in C.items():
        W.setdefault(i, {})
        for j, cij in ilist.items():
            W[i][j] = cij / N[i]

    sorted_item_sim = {k: list(sorted(v.items(),\
                                      key=lambda x: x[1], reverse=True)[0:save_n]) \
                       for k, v in W.items()}

    return sorted_item_sim, UserItem




def coCF_i2i(train,save_n=600):
    # 用户-物品的矩阵
    UserItem = dict()
    # 物品-物品的共现矩阵
    C = dict()
    # 喜欢物品i的用户数
    N = dict()
    for val in train.values:
        userid = val[0]
        itemid = val[1]
        UserItem.setdefault(userid, {})
        UserItem[userid][itemid] = 1

    for _, itemids in UserItem.items():
        for itemid in itemids.keys():
            N.setdefault(itemid, 0)
            N[itemid] += 1
            C.setdefault(itemid, {})
            for i in itemids.keys():
                if itemid == i:
                    continue
                C[itemid].setdefault(i, 0)
                C[itemid][i] += 1

    W = dict()
    for i, ilist in C.items():
        W.setdefault(i, {})
        for j, cij in ilist.items():
            W[i][j] = cij / N[i]

    sorted_item_sim = {k: list(sorted(v.items(),\
                                      key=lambda x: x[1], reverse=True)[0:save_n]) \
                       for k, v in W.items()}

    return sorted_item_sim, UserItem


def coCF_u2i(train,save_n=600):
    # 用户-商品的共现矩阵
    UserItem = dict()
    # 用户喜欢的商品数
    N = dict()

    for val in train.values:
        userid = val[0]
        itemid = val[1]

        N.setdefault(userid, 0)
        N[userid] += 1

        UserItem.setdefault(userid, {})
        UserItem[userid].setdefault(itemid, 0)
        UserItem[userid][itemid] += 1

    W = dict()
    for i, ilist in UserItem.items():
        W.setdefault(i, {})
        for j, cij in ilist.items():
            W[i][j] = cij / N[i]
    sorted_item_sim = {k: list(sorted(v.items(), \
                                      key=lambda x: x[1], reverse=True)[0:save_n]) \
                       for k, v in W.items()}
    return sorted_item_sim, UserItem


def coCF_c2c(train,save_n = 600):
    #用户-分类的矩阵
    UserCategory = dict()
    #分类-分类的共现矩阵
    C = dict()
    #喜欢分类i的用户数
    N = dict()
    for val in train.values:
        userid = val[0]
        Categoryid = val[2]
        UserCategory.setdefault(userid,{})
        UserCategory[userid][Categoryid] = 1

    for userid, Categoryids in UserCategory.items():
        for Categoryid in Categoryids.keys():
            N.setdefault(Categoryid,0)
            N[Categoryid] += 1
            C.setdefault(Categoryid,{})
            for i in Categoryids.keys():
                if Categoryid == i:
                    continue
                C[Categoryid].setdefault(i,0)
                C[Categoryid][i] += 1

    W = dict()
    for i, ilist in C.items():
        W.setdefault(i,{})
        for j, cij in ilist.items():
            W[i][j] = cij/N[i]
    sorted_item_sim = {k: list(sorted(v.items(), \
                               key=lambda x: x[1], reverse=True)[0:save_n]) \
                       for k, v in W.items()}
    return sorted_item_sim,UserCategory


def coCF_c2i(train,save_n=600):
    # 分类-商品的共现矩阵
    CategoryItem = dict()
    # 分类i出现的商品数
    N = dict()

    for val in train.values:
        Categoryid = val[2]
        itemid = val[1]

        N.setdefault(Categoryid, 0)
        N[Categoryid] += 1

        CategoryItem.setdefault(Categoryid, {})
        CategoryItem[Categoryid].setdefault(itemid, 0)
        CategoryItem[Categoryid][itemid] += 1

    W = dict()
    for i, ilist in CategoryItem.items():
        W.setdefault(i, {})
        for j, cij in ilist.items():
            W[i][j] = cij / N[i]
    sorted_item_sim = {k: list(sorted(v.items(), \
                                      key=lambda x: x[1], reverse=True)[0:save_n]) \
                       for k, v in W.items()}
    return sorted_item_sim, CategoryItem


def recommend_i2i(user, UserItem_i2i, W_i2i, k=400, n=50):
    rank = dict()
    if user not in UserItem_i2i.keys():
        return dict()
    action_items = UserItem_i2i[user]
    for item, score in action_items.items():
        for i, wi in W_i2i[item][0:k]:
            rank.setdefault(i, 0)
            rank[i] += score * wi

    temp = sorted(rank.items(), key=lambda x: x[1], reverse=True)[0:n]
    if len(temp) < 1:
        return dict()
    max = list(temp)[0][1]
    temp = dict(temp)

    rank_new = {k: v / max for k, v in temp.items()}
    return rank_new


def recommend_u2u(user, UserItem_u2u, W_u2u, k=330, n=50):
    rank = dict()
    if user not in UserItem_u2u.keys():
        return dict()
    for userid, wi in W_u2u[user][0:k]:
        for i, score in UserItem_u2u[userid].items():
            rank.setdefault(i, 0)
            rank[i] += score * wi

    temp = sorted(rank.items(), key=lambda x: x[1], reverse=True)[0:n]
    if len(temp) < 1:
        return dict()
    max = list(temp)[0][1]
    temp = dict(temp)
    rank_new = {k: v / max for k, v in temp.items()}
    return rank_new


def recommend_c2i(user, UserCategory_c2c, W_c2c, CategoryItem_c2i, W_c2i, k=330, n_c=100, n=50):
    rank = dict()
    if user not in UserCategory_c2c.keys():
        return dict()
    action_category = UserCategory_c2c[user]
    for categoryid, score in action_category.items():
        for i, wi in W_c2c[categoryid][0:k]:
            rank.setdefault(i, 0)
            rank[i] += score * wi

    cate_rank = dict(sorted(rank.items(), key=lambda x: x[1], reverse=True)[0:n_c])

    ranki = dict()
    for categoryid, score in cate_rank.items():
        if categoryid not in CategoryItem_c2i.keys():
            continue
        for i, wi in W_c2i[categoryid][0:k]:
            ranki.setdefault(i, 0)
            ranki[i] += score * wi

    temp = sorted(ranki.items(), key=lambda x: x[1], reverse=True)[0:n]
    if len(temp) < 1:
        return dict()
    max = list(temp)[0][1]
    temp = dict(temp)
    item_rank = {k: v / max for k, v in temp.items()}
    return item_rank


def recommend_u2i(user,UserItem_u2i, W_u2i, k=330, n=50):
    rank = dict()
    if user not in UserItem_u2i.keys():
        return dict()
    for item, score in W_u2i[user][0:k]:
        rank.setdefault(item, 0)
        rank[item] += score

    temp = sorted(rank.items(), key=lambda x: x[1], reverse=True)[0:n]
    if len(temp) < 1:
        return dict()
    max = list(temp)[0][1]
    temp = dict(temp)
    rank_new = {k: v / max for k, v in temp.items()}
    return rank_new


def merge2dict(dict1, dict2, n, a, b, c):
    num1 = len(dict1)
    num2 = len(dict2)
    dict1_new = dict(sorted(dict1.items(), key=lambda x: x[0]))
    dict2_new = dict(sorted(dict2.items(), key=lambda x: x[0]))
    merge_dict = dict()

    i = 0
    j = 0
    while i < num1 and j < num2:
        itemid1, score1 = list(dict1_new.items())[i]
        itemid2, score2 = list(dict2_new.items())[j]
        if itemid1 == itemid2:
            merge_dict[itemid1] = (score1 * a + score2 * (1 - a)) * b
            i += 1
            j += 1
        elif itemid1 > itemid2:
            merge_dict[itemid2] = score2
            j += 1
        elif itemid1 < itemid2:
            merge_dict[itemid1] = score1 * c
            i += 1

    while i < num1:
        itemid1, score1 = list(dict1_new.items())[i]
        merge_dict[itemid1] = score1
        i += 1

    while j < num2:
        itemid2, score2 = list(dict2_new.items())[j]
        merge_dict[itemid2] = score2
        j += 1
    merge_dict_new = dict(sorted(merge_dict.items(), key=lambda x: x[1], reverse=True)[0:n])
    return merge_dict_new


def match(user,UserItem_i2i, W_i2i,UserItem_u2u, W_u2u,UserItem_u2i, W_u2i,flag=0, k=400, n=200, a=0.51, b=1.1, c=2.4):
    i2i_dict = recommend_i2i(user, UserItem_i2i, W_i2i, k, n)
    u2i_dict = recommend_u2i(user, UserItem_u2i, W_u2i, k, n)
    merge_data = merge2dict(i2i_dict, u2i_dict, n, 0.51 , 1.2, 1.6)

    '''
    if flag == 1:
        u2i_dict = recommend_u2i(user, UserItem_u2i, W_u2i, k, n)
        merge_data = merge2dict(u2i_dict, merge_data, n, 0.51, 1.1, 2.4)
    if flag == 2:
        c2i_dict = recommend_c2i(user,k)
        merge_data = merge2dict(merge_data,c2i_dict,n,0.56,1.8,4)
    '''
    return merge_data


def match_save(user, item2cate, UserItem_i2i, W_i2i,UserItem_u2u, W_u2u,UserItem_u2i, W_u2i,k=400, n=200, a=0.51, b=1.1, c=2.4):
    i2i_dict = recommend_i2i(user, UserItem_i2i, W_i2i, k, n)
    u2i_dict = recommend_u2i(user, UserItem_u2i, W_u2i, k, n)

    merge_data = merge2dict(i2i_dict, u2i_dict, n, a, b, c)

    #u2i_dict = recommend_u2i(user, user, UserItem_u2i, W_u2i, k, n)
    #merge_data = merge2dict(u2i_dict, merge_data, n, 0.51, 1.1, 2.4)

    #     c2i_dict = recommend_c2i(user,k)
    #     merge_data = merge2dict(merge_data,c2i_dict,n,0.56,1.8,4)

    match_list = list()
    for itemid, score in merge_data.items():
        cateid = item2cate[itemid]
        #match_list.append([user, itemid, cateid, score])
        match_list.append([user, itemid, cateid])

    return merge_data, match_list

#---------------test-------------------------


def test_match_top(test_data, UserItem_i2i, W_i2i,UserItem_u2u, W_u2u,UserItem_u2i, W_u2i, k, n, a = 0.55, b = 1.8, c = 1.3):
    score = 0
    inum = 0
    for val in test_data.values:
        inum += 1
        #if inum > 2001:
        #    break
        userid = val[0]
        itemid = val[1]
        itemlist = match(userid, UserItem_i2i, W_i2i,UserItem_u2u, W_u2u,UserItem_u2i, W_u2i,k,n,a,b,c)
        if len(itemlist) == 0:
            continue
        if itemid in itemlist.keys():
            score += 1
        if inum % 1000 == 0:
            print(inum, score)

    return inum, score

def test_match_and_savefile_top(test_data, item2cate, outfile,  UserItem_i2i, W_i2i,UserItem_u2u, W_u2u,UserItem_u2i, W_u2i,k,n,a = 0.55, b = 1.8,c = 1.3):
    score = 0
    inum = 0
    matchfile = dict()
    for val in test_data.values:
        inum += 1
        userid = val[0]
        itemid = val[1]
        itemlist , matchlist = match_save(userid, item2cate, UserItem_i2i, W_i2i,UserItem_u2u, W_u2u,UserItem_u2i, W_u2i,k,n,a,b,c)
        matchfile[userid] = matchlist

        if len(itemlist) == 0:
            continue
        if itemid in itemlist.keys():
            score += 1
        if inum % 1000 == 0:
            print(inum,score)
    print(len(matchfile))
    pickle.dump((matchfile), open(outfile, 'wb'))
    return inum,score


def test_match_u2u_top(test_data, UserItem_u2u, W_u2u,k=330,n=50):
    score = 0
    inum = 0
    for val in test_data.values:
        inum += 1
        userid = val[0]
        itemid = val[1]
        itemlist = recommend_u2u(userid, UserItem_u2u, W_u2u, k, n)
        if len(itemlist) == 0:
            continue
        if itemid in itemlist.keys():
            score += 1
        if inum % 1000 == 0:
            print(inum, score)

    return inum, score


def test_match_i2i_top(test_data, UserItem_i2i, W_i2i, k=330,n=50):
    score = 0
    inum = 0
    for val in test_data.values:
        inum += 1
        userid = val[0]
        itemid = val[1]
        itemlist = recommend_i2i(userid, UserItem_i2i, W_i2i, k, n)
        if len(itemlist) == 0:
            continue
        if itemid in itemlist.keys():
            score += 1
        if inum % 1000 == 0:
            print(inum, score)

    return inum, score


def test_match_u2i_top(test_data,UserItem_u2i, W_u2i, k=330, n=50):
    score = 0
    inum = 0
    for val in test_data.values:
        inum += 1
        userid = val[0]
        itemid = val[1]
        itemlist = recommend_u2i(userid,UserItem_u2i, W_u2i, k, n)
        if len(itemlist) == 0:
            continue
        if itemid in itemlist.keys():
            score += 1
        if inum % 1000 == 0:
            print(inum, score)

    return inum, score

def test_match_c2i_top(test_data, k=330):
    score = 0
    inum = 0
    for val in test_data.values:
        inum += 1
        userid = val[0]
        itemid = val[1]
        itemlist = recommend_c2i(userid, k)
        if len(itemlist) == 0:
            continue
        if itemid in itemlist.keys():
            score += 1
        if inum % 1000 == 0:
            print(inum, score)

    return inum, score


if __name__ == '__main__':
    infile = '../data/matchdata.dat'
    match_train_data, match_test_data, item2cate = pickle.load(open(infile, mode='rb'))
    '''
    save_n = 800
    w_u2u, ItemUser_u2u, UserItem_u2u = coCF_u2u(match_train_data, save_n)
    pickle.dump((w_u2u, ItemUser_u2u, UserItem_u2u), open('../data/match_data/cf_u2u_800', 'wb'))
    del w_u2u, ItemUser_u2u, UserItem_u2u
    gc.collect()
    print('u2u')
    
    print('starting i2i')
    save_n = 800
    w_i2i, UserItem_i2i = coCF_i2i(match_train_data, save_n)
    pickle.dump((w_i2i, UserItem_i2i), open('../data/match_data/cf_i2i_800', 'wb'))
    del w_i2i, UserItem_i2i
    gc.collect()
    print('i2i')
    '''
    w_i2i, UserItem_i2i = pickle.load(open('../data/match_data/cf_i2i_800', mode='rb'))
    k = 400
    n = 50
    print('i2i start')
    inum, score = test_match_i2i_top(match_test_data, UserItem_i2i, w_i2i, k, n)
    print(inum, score)



