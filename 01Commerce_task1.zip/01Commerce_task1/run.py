run main function
