import os
import pickle


def save_file(filepath, data):
    """
        保存数据
        @param filepath:    保存路径
        @param data:    要保存的数据
    """
    parent_path = filepath[: filepath.rfind("/")]

    if not os.path.exists(parent_path):
        os.mkdir(parent_path)
    with open(filepath, "wb") as f:
        pickle.dump(data, f)


def load_file(filepath):
    """载入二进制数据"""
    with open(filepath, "rb") as f:
        data = pickle.load(f)
    return data


def open_text(filename,skip_row = 0):
    """打开文本文件

    :param filename: str
        文件名
    :param skip_row: int
         需要跳过的行数
    :return generator
        生成每一行的文本
    """
    with open(filename, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i < skip_row:
                continue
            yield line

def load_data(file_path):
    data_list = list()
    with open(file_path, 'r', encoding = 'UTF-8') as f:
        for line in f:
            ll = line.strip().split(",")
            data_list.append([int(ll[0]), int(ll[1]), int(ll[3])])
    return data_list

def recall(recommends, tests):
    """
        计算Recall
        @param recommends:   给用户推荐的商品，recommends为一个dict，格式为 { userID : 推荐的物品 }
        @param tests:  测试集，同样为一个dict，格式为 { userID : 实际发生事务的物品 }
        @return: Recall
    """
    score = 0
    for user_id, items in recommends.items():
        recommend_set = set(items)
        test_item = tests[user_id]
        if test_item in recommend_set:
            score += 1

    return score
