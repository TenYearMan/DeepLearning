import pandas as pd
import random
import math
import time


# 定义装饰器，监控运行时间
def timmer(func):
    def wrapper(*args, **kwargs): # args:tuple, kwargs:dict
        start_time = time.time()
        res = func(*args, **kwargs)
        stop_time = time.time()
        print("Func: %s, run time: %s" % (func.__name__, stop_time-start_time))
        return res
    return wrapper


# 数据处理
class Dataset():
    def __init__(self, fp):
        self.data = self.loadData(fp)
    @timmer
    def loadData(self, fp):
        data_dict = {}
        with open(fp, 'r', encoding = 'UTF-8') as f:
            for line in f:
                ll = line.strip().split(",")
                if ll[0] not in data_dict:
                    data_dict[ll[0]] = {}
                data_dict[ll[0]][ll[1]] = ll[3]
        return data_dict

#评价指标，召回10中命中率
class Metric():
    def __init__(self, train, test, getRecommendation):
        self.train = train
        self.test = test
        self.getRecommendation = getRecommendation
        #self.recs = self.getRec()
    #为test中每个user推荐item
    #def getRec():
        #recs = {}
        #for user in self.test:
            #rank = self.getRecommendation(user)
            #recs[user] = rank
        #return recs
    # 定义得分函数
    def getRecallScore(self):
        score = 0
        for userid in self.test:
            rank = self.getRecommendation(userid)
            for itemid in self.test[userid]:
                items_re = []
                for item, _ in rank:
                    items_re.append(item)
                if len(items_re) == 0:
                    continue
                if itemid in items_re:
                    score += 1
                #print("Recall top50 score:", score)
        return score
    def eval(self):
        metric = {'getRecallScore': self.getRecallScore()}
        print('Metric:', metric)
        return metric


# 算法实现
def ItemIUF(train, K, N):
    '''
    :params: train, 训练数据集
    :params: K, 超参数，设置取TopK相似物品数目
    :params: N, 超参数，设置取TopN推荐物品数目
    :return: GetRecommendation, 推荐接口函数
    '''
    # 计算物品相似度矩阵
    sim = {}
    num = {}
    for user in train:
        items = train[user]
        for i in items.keys():
            num.setdefault(i, 0)
            num[i] += 1
            sim.setdefault(i, {})
            for j in items.keys():
                if j == i: continue
                sim[i].setdefault(j, 0)
                # 相比ItemCF，主要是改进了这里
                sim[i][j] += 1 / math.log(1 + len(items))
    for u in sim:
        for v in sim[u]:
            sim[u][v] /= math.sqrt(num[u] * num[v])

    # 按照相似度排序
    sorted_item_sim = {k: list(sorted(v.items(), \
                                      key=lambda x: x[1], reverse=True)) \
                       for k, v in sim.items()}

    # 获取接口函数
    def GetRecommendation(user):
        items = {}
        seen_items = train[user]
        for item, score in seen_items.items():
            for i, wi in sorted_item_sim[item][:K]:
                # if u not in seen_items:
                if i not in items:
                    items[i] = 0
                items[i] += int(score) * wi
        recs = list(sorted(items.items(), key=lambda x: x[1], reverse=True))[:N]
        return recs

    return GetRecommendation


# 算法实现 基于用户余弦相似度的推荐
def UserCF(train, K, N):
    '''
    :params: train, 训练数据集
    :params: K, 超参数，设置取TopK相似用户数目
    :params: N, 超参数，设置取TopN推荐物品数目
    :return: GetRecommendation, 推荐接口函数
    '''
    # 计算item->user的倒排索引
    item_users = {}
    for user in train:
        for item, score in train[user].items():
            if item not in item_users:
                item_users[item] = {}
            item_users[item][user] = score

    # 计算用户相似度矩阵
    sim = {}
    num = {}
    for item in item_users:
        users = item_users[item]
        for u in users.keys():
            if u not in num:
                num[u] = 0
            num[u] += 1
            if u not in sim:
                sim[u] = {}
            for v in users.keys():
                if v == u: continue
                if v not in sim[u]:
                    sim[u][v] = 0
                sim[u][v] += 1
    for u in sim:
        for v in sim[u]:
            sim[u][v] /= math.sqrt(num[u] * num[v])

    # 按照相似度排序
    sorted_user_sim = {k: list(sorted(v.items(), \
                                      key=lambda x: x[1], reverse=True)) \
                       for k, v in sim.items()}

    # 获取接口函数
    def GetRecommendation(user):
        items = {}
        seen_items = train[user]
        for item, score in seen_items.items():
            for u, wu in sorted_user_sim[user][:K]:
                for item in train[u]:
                    # 要去掉用户见过的
                    if item not in seen_items:
                        if item not in items:
                            items[item] = 0
                        items[item] += int(score) * wu
        recs = list(sorted(items.items(), key=lambda x: x[1], reverse=True))[:N]
        return recs

    return GetRecommendation


class Experiment():
    def __init__(self, K, N, fp_train='./data/data_train.csv', fp_test='./data/data_test.csv', rt='UserCF'):
        self.K = K  # topK相似物品个数
        self.N = N  # topN推荐物品个数
        self.fp_train = fp_train
        self.fp_test = fp_test
        self.rt = rt
        self.alg = {'UserCF': UserCF, 'ItemIUF': ItemIUF}

    @timmer
    def worker(self, train, test):
        getRecommendation = self.alg[self.rt](train, self.K, self.N)
        metric = Metric(train, test, getRecommendation)
        return metric.eval()

    @timmer
    def run(self):
        metrics = {'getRecallScore': 0}
        data_train = Dataset(self.fp_train)
        data_test = Dataset(self.fp_test)
        metric = self.worker(data_train.data, data_test.data)


if __name__ == "main":
    cf_exp = Experiment(200, 10, rt='ItemIUF')
    cf_exp.run()
