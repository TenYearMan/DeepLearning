import pickle
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
import warnings
from sklearn.externals import joblib
warnings.filterwarnings('ignore')


def lr_model(x_train,y_train,save_dir):
    lr = LogisticRegression()
    lr.fit(x_train, y_train)
    y_pred = lr.predict_proba(x_train)
    train_auc = roc_auc_score(y_train, y_pred[:, 1])
    print('train_auc:%.4f' % (train_auc))

    joblib.dump(lr, save_dir)

if __name__ == '__main__':
    infile = '../data/rankdata.dat'
    save_dir = '../save/LR.model'
    train_index, _, train_target, test_index, _, test_target, \
    _, _ = pickle.load(open(infile, mode='rb'))
    ilen = len(train_target)
    y = np.reshape(train_target, (ilen,))
    itlen = len(test_target)
    y_test = np.reshape(test_target, (itlen,))

    lr_model(train_index, y, save_dir)

    print('Load Model...')
    lr = joblib.load(save_dir)
    y_test_pred = lr.predict_proba(test_index)
    test_auc = roc_auc_score(y_test, y_test_pred[:, 1])
    print('test_auc:%.4f' %  (test_auc))
