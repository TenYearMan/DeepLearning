import numpy as np
import pickle
import tensorflow as tf
from matplotlib import pyplot as plt
from sklearn.metrics import roc_auc_score
from DeepFM import DeepFM
import time


def _run_base_model_dfm(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, dfm_params):
    dfm_params["feature_size"] = feature_size
    dfm_params["field_size"] = field_size

    dfm = DeepFM(**dfm_params)
    dfm.fit(train_index, train_val, train_target)

    train_result = dfm.evaluate(train_index, train_val, train_target)

    test_result = dfm.evaluate(test_index, test_val, test_target)
    dfm.savemodle(save_dir)
    print('train_result:[%.4f] test_result:[%.4f] ' % (train_result, test_result))


def _test_base_model_dfm(save_dir, mfile, mmfile, feature_size, field_size, topn, dfm_params):
    dfm_params["feature_size"] = feature_size
    dfm_params["field_size"] = field_size
    _, test_data, _ = pickle.load(open(mfile, mode='rb'))
    matchfile = pickle.load(open(mmfile, mode='rb'))
    dfm = DeepFM(**dfm_params)
    dfm.restore(save_dir)

    inum = 0
    re_score = 0
    t1 = time.time()
    for val in test_data.values:
        inum += 1
        user = val[0]
        item = val[1]

        match_list = matchfile[user]

        array_data = np.array(match_list, dtype=np.int)
        ilen = len(array_data)
        if ilen <= 0:
            continue
        m, n = np.shape(match_list)
        match_val = np.array([[1.0] * n] * m, dtype=np.float)
        y_pred = dfm.predict(array_data, match_val)
        y_pred = np.reshape(y_pred, [m, 1])

        item_score = np.concatenate((array_data[:, 1:2], y_pred), axis=1)
        rerank = dict(sorted(item_score, key=lambda x: x[1], reverse=True)[0:topn])
        if len(rerank) == 0:
            continue
        if item in rerank:
            re_score += 1

        if inum % 1000 == 0:
            t2 = time.time()
            print(inum, re_score, t2 - t1)
            t1 = t2

    return inum, re_score


def _plot_fig(train_results, valid_results, model_name):
    colors = ["red", "blue", "green"]
    xs = np.arange(1, train_results.shape[1] + 1)
    plt.figure()
    legends = []
    for i in range(train_results.shape[0]):
        plt.plot(xs, train_results[i], color=colors[i], linestyle="solid", marker="o")
        plt.plot(xs, valid_results[i], color=colors[i], linestyle="dashed", marker="o")
        legends.append("train-%d" % (i + 1))
        legends.append("valid-%d" % (i + 1))
    plt.xlabel("Epoch")
    plt.ylabel("Normalized Gini")
    plt.title("%s" % model_name)
    plt.legend(legends)
    plt.savefig("./fig/%s.png" % model_name)
    plt.close()


# ------------------ DeepFM Model ------------------
# params
dfm_params = {
    "use_fm": True,
    "use_deep": True,
    "embedding_size": 8,
    "dropout_fm": [1.0, 1.0],
    "deep_layers": [32, 32],
    "dropout_deep": [0.5, 0.5, 0.5],
    "deep_layers_activation": tf.nn.relu,
    # "deep_layers_activation": tf.nn.sigmoid,
    "epoch": 30,
    "batch_size": 1024,
    "learning_rate": 0.0001,
    "optimizer_type": "adam",
    # "batch_norm": 1,
    # "batch_norm_decay": 0.995,
    "l2_reg": 0.01,
    "verbose": True,
    "eval_metric": roc_auc_score,
    "random_seed": 2019
}
if __name__ == '__main__':
    infile = '../data/rankdata.dat'
    train_index, train_val, train_target, test_index, test_val, test_target, \
    feature_size, field_size = pickle.load(open(infile, mode='rb'))
    print(feature_size, field_size)

    # ------------------ DeepFM Model ------------------
    print('start DeepFM')
    save_dir = '../save/DFM.model'
    _run_base_model_dfm(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, dfm_params)

    # ------------------ FM Model ------------------
    print('start FM')
    fm_params = dfm_params.copy()
    fm_params["use_deep"] = False
    save_dir = '../save/FM.model'
    _run_base_model_dfm(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, dfm_params)

    # ------------------ DNN Model ------------------
    print('start dnn')
    dnn_params = dfm_params.copy()
    dnn_params["use_fm"] = False
    save_dir = '../save/DNN.model'
    _run_base_model_dfm(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, dfm_params)

