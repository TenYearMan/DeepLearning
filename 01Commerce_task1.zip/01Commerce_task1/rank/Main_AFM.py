import pickle
import tensorflow as tf
from AFM import AFM


def _run_base_model_afm(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, dfm_params):
    afm_params["feature_size"] = feature_size
    afm_params["field_size"] = field_size

    afm = AFM(**afm_params)
    afm.fit(train_index, train_val, train_target)

    train_result = afm.evaluate(train_index, train_val, train_target)

    test_result = afm.evaluate(test_index, test_val, test_target)
    afm.savemodle(save_dir)
    print('train_result:[%.4f] test_result:[%.4f] ' % (train_result, test_result))

# ------------------ DCN Model ------------------
# params
afm_params = {
    "embedding_size": 8,
    "deep_layers": [32,32],
    "dropout_deep": [0.5, 0.5, 0.5],
    "deep_layers_activation": tf.nn.relu,
    "epoch": 20,
    "batch_size": 1024,
    "learning_rate": 0.001,
    "optimizer_type": "adam",
    "verbose": True,
    "random_seed": 2019,
     "deep_init_size": 50,
}
if __name__ == '__main__':
    infile = '../data/rankdata.dat'
    train_index, train_val, train_target, test_index, test_val, test_target, \
    feature_size, field_size = pickle.load(open(infile, mode='rb'))
    print(feature_size, field_size)

    # ------------------ DCN Model ------------------
    print('start AFM')
    save_dir = '../save/AFM.model'
    _run_base_model_afm(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, afm_params)
