import pickle
import tensorflow as tf
from DCN import DCN


def _run_base_model_dcn(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, dfm_params):
    dcn_params["feature_size"] = feature_size
    dcn_params["field_size"] = field_size

    dcn = DCN(**dcn_params)
    dcn.fit(train_index, train_val, train_target)

    train_result = dcn.evaluate(train_index, train_val, train_target)

    test_result = dcn.evaluate(test_index, test_val, test_target)
    dcn.savemodle(save_dir)
    print('train_result:[%.4f] test_result:[%.4f] ' % (train_result, test_result))

# ------------------ DCN Model ------------------
# params
dcn_params = {

    "embedding_size": 8,
    "deep_layers": [32, 32],
    "dropout_deep": [0.5, 0.5, 0.5],
    "deep_layers_activation": tf.nn.relu,
    "epoch": 20,
    "batch_size": 1024,
    "learning_rate": 0.001,
    "optimizer_type": "adam",
    "l2_reg": 0.01,
    "verbose": True,
    "random_seed": 2019,
    "cross_layer_num": 3
}
if __name__ == '__main__':
    infile = '../data/rankdata.dat'
    train_index, train_val, train_target, test_index, test_val, test_target, \
    feature_size, field_size = pickle.load(open(infile, mode='rb'))
    print(feature_size, field_size)

    # ------------------ DCN Model ------------------
    print('start DCN')
    save_dir = '../save/DCN.model'
    _run_base_model_dcn(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, dcn_params)
