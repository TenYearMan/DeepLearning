import pandas as pd
import pickle

data_title = ['userid', 'itemid', 'categoryid', 'behavior', 'timestamp']
datafile = '../data/data.csv'
rankdata = '../data/rankdata.dat'
matchdata = '../data/matchdata.dat'

def rank_data():
    data = pd.read_csv(datafile, sep=',', header=None, names=data_title)
    data['time'] = pd.to_datetime(data['timestamp'].values, utc=True, unit='s').tz_convert("Asia/Shanghai")
    data = data[(data.time.dt.date >= pd.Timestamp(2017, 11, 25).date()) &
                (data.time.dt.date <= pd.Timestamp(2017, 12, 3).date())]
    data = data.sort_values(by='timestamp', axis=0, ascending=True)
    data['label'] = data['behavior'].apply(lambda x: 1 if x == 'buy' else 0)

    userid_set = set()
    for val in data['userid']:
        userid_set.add(val)
    userid_len = len(userid_set)
    userid2int = {val: i for i, val in enumerate(userid_set)}
    data['userid'] = data['userid'].map(userid2int)

    itemid_set = set()
    for val in data['itemid']:
        itemid_set.add(val)
    itemid_len = len(itemid_set)
    itemid2int = {val: i + userid_len for i, val in enumerate(itemid_set)}
    data['itemid'] = data['itemid'].map(itemid2int)

    categoryid_set = set()
    for val in data['categoryid']:
        categoryid_set.add(val)
    categoryid_len = len(categoryid_set)
    categoryid2int = {val: i + userid_len + itemid_len for i, val in enumerate(categoryid_set)}
    data['categoryid'] = data['categoryid'].map(categoryid2int)
    feature_size = userid_len + itemid_len + categoryid_len
    field_size = 3

    rankData = data.copy()
    train_len = int(rankData.shape[0] * 0.8)
    train_data = rankData[:train_len]
    test_data = rankData[train_len:]

    feature_fields = ['userid', 'itemid', 'categoryid']
    target_fields = ['label']

    train_feature, train_target = train_data[feature_fields], train_data[target_fields]
    train_feature_values = train_feature.values
    train_target_values = train_target.values

    train_val = train_data.copy()
    train_val[feature_fields] = 1.0
    train_feature_val = train_val[feature_fields]
    train_feature_val_values = train_feature_val.values

    test_feature, test_target = test_data[feature_fields], test_data[target_fields]
    test_feature_values = test_feature.values
    test_target_values = test_target.values

    test_val = test_data.copy()
    test_val[feature_fields] = 1.0
    test_feature_val = test_val[feature_fields]
    test_feature_val_values = test_feature_val.values
    print('rank data ok')

# -----------------------match data------------------------------
    rankData = data.copy()
    print(rankData.head())
    rankData = rankData[data_title]
    print(rankData.head())
    rankData = rankData.groupby('userid').apply(lambda x: x.sort_values(by='timestamp', axis=0, ascending=True))
    rankData = pd.DataFrame(rankData.values, columns=data_title)

    match_test_data = rankData.groupby('userid').head(1)
    match_train_data = rankData.drop(match_test_data.index.values)

    item2cate = dict()
    for val in rankData.values:
        item2cate[val[1]] = val[2]

    return train_feature_values, train_feature_val_values,train_target_values, test_feature_values, test_feature_val_values, \
           test_target_values, feature_size, field_size, match_train_data,match_test_data,item2cate

if __name__ == '__main__':
    train_feature_values, train_feature_val_values, train_target_values, test_feature_values, test_feature_val_values, \
    test_target_values, feature_size, field_size, match_train_data, match_test_data, item2cate = rank_data()

    pickle.dump((train_feature_values, train_feature_val_values, train_target_values, test_feature_values, test_feature_val_values, \
    test_target_values, feature_size, field_size), open(rankdata, 'wb'))
    print(0)
    pickle.dump((match_train_data, match_test_data, item2cate), open(matchdata, 'wb'))
