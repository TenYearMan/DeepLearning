import pandas as pd
import tensorflow as tf

from dataparser_deepfm import FeatureDictionary, DataParser
from models.DeepFM import DeepFM
from models.DCN import DCN
from sklearn.metrics import roc_auc_score


def _run_base_model_dfm(train_index, train_val, train_target,
                        test_index, test_val, test_target,
                        feature_size, field_size, save_dir, dfm_params):
    dfm_params["feature_size"] = feature_size
    dfm_params["field_size"] = field_size

    dfm = DeepFM(**dfm_params)
    dfm.fit(train_index, train_val, train_target)

    train_result = dfm.evaluate(train_index, train_val, train_target)

    test_result = dfm.evaluate(test_index, test_val, test_target)
    dfm.savemodle(save_dir)
    print('train_result:[%.4f] test_result:[%.4f] ' % (train_result,test_result))


def _run_base_model_dcn(train_index, train_val, train_target,
                        test_index, test_val, test_target ,
                        feature_size, field_size, save_dir, dcn_params):
    dcn_params["feature_size"] = feature_size
    dcn_params["field_size"] = field_size

    dcn = DCN(**dcn_params)
    dcn.fit(train_index, train_val, train_target)

    train_result = dcn.evaluate(train_index, train_val, train_target)

    test_result = dcn.evaluate(test_index, test_val, test_target)
    dcn.savemodle(save_dir)
    print('train_result:[%.4f] test_result:[%.4f] ' % (train_result, test_result))
# ------------------ DeepFM Model ------------------
# params
dfm_params = {
    "use_fm": True,
    "use_deep": True,
    "embedding_size": 8,
    "dropout_fm": [1.0, 1.0],
    "deep_layers": [32, 32],
    "dropout_deep": [0.5, 0.5, 0.5],
    "deep_layers_activation": tf.nn.relu,
    # "deep_layers_activation": tf.nn.sigmoid,
    "epoch": 20,
    "batch_size": 1024,
    "learning_rate": 0.001,
    "optimizer_type": "adam",
    # "batch_norm": 1,
    # "batch_norm_decay": 0.995,
    "l2_reg": 0.01,
    "verbose": True,
    "eval_metric": roc_auc_score,
    "random_seed": 2019
}
dcn_params = {

    "embedding_size": 8,
    "deep_layers": [32, 32],
    "dropout_deep": [0.5, 0.5, 0.5],
    "deep_layers_activation": tf.nn.relu,
    "epoch": 20,
    "batch_size": 1024,
    "learning_rate": 0.001,
    "optimizer_type": "adam",
    "l2_reg": 0.01,
    "verbose": True,
    "random_seed": 2019,
    "cross_layer_num": 3
}
if __name__ == "__main__":
    train_file = "./data/train_nosampling.csv"
    test_file = "./data/test_nosampling.csv"

    IGNORE_FEATURES = ['action', 'timestamp']
    dfTrain = pd.read_csv(train_file, names=['userid', 'itemid', 'categoryid', 'action', 'timestamp'])
    dfTest = pd.read_csv(test_file, names=['userid', 'itemid', 'categoryid', 'action', 'timestamp'])

    fd = FeatureDictionary(dfTrain=dfTrain, dfTest=dfTest, ignore_cols=IGNORE_FEATURES)
    data_parser = DataParser(feat_dict=fd)
    Xi_train, Xv_train, y_train = data_parser.parse(df=dfTrain, has_label=True)
    Xi_test, Xv_test, y_test = data_parser.parse(df=dfTest, has_label=True)

    feature_size_ = fd.feat_dim
    field_size_ = len(Xi_train[0])

    # ------------------ DeepFM Model ------------------
    print('start DeepFM')
    save_dir = './save/model_dfm/model'
    _run_base_model_dfm(Xi_train, Xv_train, y_train,
                        Xi_test, Xv_test, y_test,
                        feature_size_, field_size_, save_dir, dfm_params)

    '''
    # ------------------ DCN Model ------------------
    print('start DCN')
    save_dir = './models/model'
    _run_base_model_dcn(Xi_train, Xv_train, y_train,
                        Xi_test, Xv_test, y_test,
                        feature_size_, field_size_, save_dir, dcn_params)
    '''
